export default UserTypes = {
    TRAINER: "51882a3c-33f9-4ff5-a721-4d1ba86430e2",
    CLIENT: "5a9b19d7-09c2-4c88-8254-c19277896160",
    ADMIN: "40eec394-8d0f-426a-a43a-f4a55e3efea1",
    SUPERADMIN: "ae78a41e-f9a7-4bc9-b020-df5239be398f"
}