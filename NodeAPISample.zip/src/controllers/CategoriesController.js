const express = require('express');
const CategoriesRoute = express.Router();
const Category = require('../models/categories').default;
const users = require('../models/users').default;
const validateToken = require('../middleware').default;
const UserTypes = require('../enums/user-types').default;

CategoriesRoute.use(async (req, res, next) => {
    next();
})

CategoriesRoute.get('/', validateToken, async (req, res, next) => {
    if (!req.headers.authorization) {
        next();
    }
    try {
        const token = req.headers.authorization.split(' ')[1];
        const decodedToken = jwt.decode(token);
        const u = await users.query()
            .leftJoin('user_type', 'user_type.id', 'users.user_type_id')
            .where('users.is_deleted', false)
            .andWhere('users.id', decodedToken.userid).first();
        let c;
        if (u && u.user_type_id === UserTypes.SUPERADMIN) {
            c = await Category.query().where('is_active', true);
        } else if (u && u.user_type_id === UserTypes.ADMIN) {
            c = await Category.query().where('is_active', true);
        } else if (u && u.user_type_id === UserTypes.CLIENT) {
            c = await Category.query().where('is_active', true);
        }
        res.send({
            res: c
        });
    } catch (error) {
        console.log(`Category: Error while getting all categories with details : ${JSON.stringify(error, null, 2)}`);
        res.send(
            JSON.stringify({
                message: error.message,
                stack: error.stack
            })
        );
    }
})


CategoriesRoute.get('/:id', validateToken, async (req, res, next) => {
    try {
        const c = await Category.query().where('id', req.params.id).andWhere('is_active', true).first();
        res.send({
            res: c
        });
    } catch (error) {
        console.log(`Category: Error while getting category by ID with details : ${JSON.stringify(error, null, 2)}`);
        res.send(
            JSON.stringify({
                message: error.message,
                stack: error.stack
            })
        );
    }
})

CategoriesRoute.put('/', validateToken, async (req, res, next) => {
    try {
        let obj = {
            id: req.body.id,
            name: req.body.name,
            type: req.body.type,
            business_owner_id: req.body.business_owner_id
        }
        const c = await Category.query().upsertGraphAndFetch(obj, { relate: true, unrelate: true });
        res.send({
            res: obj
        });
    } catch (error) {
        console.log(`Category: Error while updating category with details : ${JSON.stringify(error, null, 2)}`);
        res.send(
            JSON.stringify({
                message: error.message,
                stack: error.stack
            })
        );
    }
})

CategoriesRoute.post('/', validateToken, async (req, res, next) => {
    let obj = {
        name: req.body.name,
        type: req.body.type,
        business_owner_id: req.body.business_owner_id
    }
    try {
        const c = await Category.query().insertGraphAndFetch(obj);
        res.send({
            res: c
        });
    } catch (error) {
        console.log(`Category: Error while saving category with details : ${JSON.stringify(error, null, 2)}`);
        res.send(
            JSON.stringify({
                message: error.message,
                stack: error.stack
            })
        );
    }
});
export default CategoriesRoute;